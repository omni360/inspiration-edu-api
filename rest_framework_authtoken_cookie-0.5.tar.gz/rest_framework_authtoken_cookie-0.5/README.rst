======================================
Django-REST-framework authtoken cookie
======================================

A Django app to add the ability to authenticate using an
authentication-token in DRF's browsable API interface.

After getting the token from the user once, the middleware transparently
copies it to the appropriate HTTP header, for DRF's authtoken module to handle.
This means that if you're already using TokenAuthentication as an authentication_class
in any of your views, you don't have to change anything.

Quick start
-----------

1. Add the app to your INSTALLED_APPS setting like this:

    INSTALLED_APPS = (
        ...
        'rest_framework_authtoken_cookie',
        'rest_framework',
        'rest_framework.authtoken',
    )

2. Add the middleware class settings like this:

    MIDDLEWARE_CLASSES = (
        ...
        'rest_framework_authtoken_cookie.auth_middleware.AuthTokenFromCookie',
    )


3. Include the URLconf in your project urls.py like this:

    url(r'^apiauth/', include('rest_framework_authtoken_cookie.urls', namespace='rest_framework_authtoken_cookie')),

4. Go to the browsable API and insert the token using the upper right link.


Building a new version
----------------------
1. Commit the changes to the source code.
2. In `setup.py` edit the version number.
3. Run `python setup.py sdist`
