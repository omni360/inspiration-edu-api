from django.conf import settings
from django.http import HttpResponseRedirect
from django.template.response import TemplateResponse
from django.utils.http import is_safe_url
from django.shortcuts import resolve_url
from django.views.decorators.debug import sensitive_post_parameters
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_protect

# Avoid shadowing the login() and logout() views below.
from django.contrib.auth import REDIRECT_FIELD_NAME
from django.contrib.auth.views import logout as auth_logout
from django.contrib.sites.models import get_current_site

from .forms import TokenForm

TOKEN_COOKIE_KEY = 'AUTH_TOKEN'


@sensitive_post_parameters()
@csrf_protect
@never_cache
def login(request, template_name='rest_framework/token_login.html',
          redirect_field_name=REDIRECT_FIELD_NAME,
          authentication_form=TokenForm,
          current_app=None, extra_context=None):
    """
    Displays the login form and handles the login action.
    """
    redirect_to = request.REQUEST.get(redirect_field_name, '')

    if request.method == "POST":
        form = authentication_form(data=request.POST)
        if form.is_valid():
            # Ensure the user-originating redirection url is safe.
            if not is_safe_url(url=redirect_to, host=request.get_host()):
                redirect_to = resolve_url(settings.LOGIN_REDIRECT_URL)

            if request.session.test_cookie_worked():
                request.session.delete_test_cookie()

            response = HttpResponseRedirect(redirect_to)
            response.set_cookie(TOKEN_COOKIE_KEY, form.cleaned_data.get('token', None))
            return response
    else:
        form = authentication_form(request)

    request.session.set_test_cookie()

    current_site = get_current_site(request)

    context = {
        'form': form,
        redirect_field_name: redirect_to,
        'site': current_site,
        'site_name': current_site.name,
    }
    if extra_context is not None:
        context.update(extra_context)

    response = TemplateResponse(request, template_name, context, current_app=current_app)
    response.delete_cookie(TOKEN_COOKIE_KEY)
    return response


def logout(request, next_page=None,
           template_name='registration/logged_out.html',
           redirect_field_name=REDIRECT_FIELD_NAME,
           current_app=None, extra_context=None):

    response = auth_logout(request, next_page=next_page,
                           template_name=template_name,
                           redirect_field_name=redirect_field_name,
                           current_app=current_app, extra_context=extra_context)
    response.delete_cookie(TOKEN_COOKIE_KEY)
    return response
