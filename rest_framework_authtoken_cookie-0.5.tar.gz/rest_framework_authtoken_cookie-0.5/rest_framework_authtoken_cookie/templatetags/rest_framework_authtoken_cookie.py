from __future__ import unicode_literals, absolute_import
from django import template
from django.core.urlresolvers import reverse, NoReverseMatch

register = template.Library()

@register.simple_tag
def optional_token_login(request):
    """
    Include a login snippet if REST framework's login view is in the URLconf.
    """
    try:
        login_url = reverse('rest_framework_authtoken_cookie:token_login')
    except NoReverseMatch:
        return ''

    snippet = "<a href='%s?next=%s'>Insert Token</a>" % (login_url, request.path)
    return snippet

@register.simple_tag
def optional_token_logout(request):
    """
    Include a logout snippet if REST framework's logout view is in the URLconf.
    """
    try:
        logout_url = reverse('rest_framework_authtoken_cookie:token_logout')
    except NoReverseMatch:
        return ''

    snippet = "<a href='%s?next=%s'>Log out</a>" % (logout_url, request.path)
    return snippet