from django import forms


class TokenForm(forms.Form):
    """
    A form that holds the single 'token' field
    """
    token = forms.CharField(max_length=254)

    def clean(self):
        self.check_for_test_cookie()
        return self.cleaned_data

    def check_for_test_cookie(self):
        if hasattr(self, 'request') and not self.request.session.test_cookie_worked():
            raise forms.ValidationError(self.error_messages['no_cookies'])