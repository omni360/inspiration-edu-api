from .views import TOKEN_COOKIE_KEY


class AuthTokenFromCookie(object):
    """
    Get the cookie value and place it in a header.
    """
    def process_request(self, request):
        # If an authorization header is preset, do nothing.
        if request.META.get('HTTP_AUTHORIZATION', None):
            return

        # Else, try getting the token from the cookie.
        token = request.COOKIES.get(TOKEN_COOKIE_KEY, None)
        request.META['HTTP_AUTHORIZATION'] = ('Token ' + token) if token else ''
