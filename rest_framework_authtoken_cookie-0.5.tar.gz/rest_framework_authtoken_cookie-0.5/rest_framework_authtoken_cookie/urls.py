from __future__ import unicode_literals
from django.conf.urls import patterns, url

urlpatterns = patterns('rest_framework_authtoken_cookie.views',
    url(r'^login/$', 'login', name='token_login'),
    url(r'^logout/$', 'logout', name='token_logout'),
)
